The template system uses ".tpl" files for rendering the pages... No need to fear, 
they are basically php files! There is no special format or anything like that :) .
Just code in html / php and the template system will do the rest.