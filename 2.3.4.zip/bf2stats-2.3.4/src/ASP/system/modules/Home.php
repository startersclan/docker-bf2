<?php
class Home
{
	public function Init() 
	{
		$Template = new Template();
		$Template->render('home');
	}
}
?>