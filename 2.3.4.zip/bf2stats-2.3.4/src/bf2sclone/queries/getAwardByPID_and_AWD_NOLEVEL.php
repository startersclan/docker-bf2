<?php
	$query = "SELECT * FROM awards where id = $PID AND awd = $AWD LIMIT 1";
?>

