<?php
	$query = "SELECT * FROM kits WHERE id = $PID;";
?>
