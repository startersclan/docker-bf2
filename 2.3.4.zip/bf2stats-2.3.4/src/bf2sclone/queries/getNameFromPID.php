<?php
	$query = "SELECT name FROM player WHERE id = $PID;";
?>
