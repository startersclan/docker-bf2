<?php
	$query = "SELECT * FROM army where id = $PID;";
?>