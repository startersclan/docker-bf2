<?php
	$query = "SELECT * FROM awards where id = $PID AND awd = $AWD AND level = $LEVEL LIMIT 1";
?>

