<?php
	$query = "SELECT id FROM player WHERE name LIKE '$NICK';";
?>