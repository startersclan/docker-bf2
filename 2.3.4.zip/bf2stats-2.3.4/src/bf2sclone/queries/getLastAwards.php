<?php
	$query = "SELECT * FROM awards WHERE id = $PID LIMIT 5;";
?>

