<?php
	$query = "SELECT id,name,rank,cmdscore,country FROM player WHERE 1=1 ORDER BY cmdscore DESC LIMIT 5;";
?>