<?php
	$query = "SELECT id,name,rank,score,country FROM player WHERE 1=1 ORDER BY score DESC LIMIT 5;";
?>
