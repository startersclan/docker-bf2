<?php
	$query = "SELECT * FROM vehicles WHERE id = $PID;";
?>
