<?php
	$query = "SELECT * FROM weapons WHERE id = $PID;";
?>
