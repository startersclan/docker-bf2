<?php
	$query = "SELECT rank FROM player WHERE id = $PID;";
?>