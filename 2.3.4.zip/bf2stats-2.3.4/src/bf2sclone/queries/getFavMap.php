<?php
	$query = "SELECT mapid FROM maps WHERE id = $PID ORDER BY time desc limit 1;";
?>
