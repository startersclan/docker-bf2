<?php
	$query = "SELECT kit,state FROM unlocks WHERE id = $PID ORDER BY kit ASC;";
?>

