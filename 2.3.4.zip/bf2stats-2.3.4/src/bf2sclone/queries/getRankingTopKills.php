<?php
	$query = "SELECT id,name,rank,kills,country FROM player WHERE 1=1 ORDER BY kills DESC LIMIT 5;";
?>
