<?php
	$query = "SELECT * FROM player WHERE id = $PID;";
?>

