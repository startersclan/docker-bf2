<?php
	$query = "SELECT time0, time1, time2, time3, time4, time5, time6 FROM kits WHERE id = $PID LIMIT 1;";
?>
