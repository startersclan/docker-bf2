<?php
	$query = "SELECT * FROM maps WHERE id = $PID ORDER BY mapid;";
?>