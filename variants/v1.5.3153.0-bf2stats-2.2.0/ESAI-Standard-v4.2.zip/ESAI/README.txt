				Enhanced Strategic AI (ESAI) Version 4.1
                                                
					    by Void

                                    Support/Questions/Improvements?                                           
		                         bf2eai@gmail.com
                                    
       
Thank you for downloading ESAI. To get started quickly, refer to the documents residing in \ESAI\Docs\.
                                                
                                              
Here is the 'Ultra Quick Start Guide':

- copy the ESAI folder to /mods/bf2/
- open a map's server.zip, and add an ESAI map file to the \AI folder for the game mode you want to test
- close the zip and load the map.

Upgrade Notes:

This version of ESAI is backwards compatable with all previous versions. If you have been using a prior version, there is no need to change anything in your ESAI enabled maps. This will always be true of official ESAI releases.

The default location for ESAI is still /mods/bf2/.

If you installed ESAI to a custom directory, you will need to again edit the paths in '../ESAI/MapFiles/default/[mapFile]/Strategies.ai' to point to the correct directory. Or, just keep the /ESAI/MapFiles/ folder from your old ESAI directory to save yourself some typing.

